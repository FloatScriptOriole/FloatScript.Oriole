/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef FLOATSCRIPT_ORIOLE_PRIVATE_H
#define FLOATSCRIPT_ORIOLE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.0.0"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	0
#define VER_BUILD	0
#define COMPANY_NAME	"Width.tech"
#define FILE_VERSION	"1.0.0.0"
#define FILE_DESCRIPTION	"Made by: Luhana Lusungu "
#define INTERNAL_NAME	"fs, TLB."
#define LEGAL_COPYRIGHT	"fs, flt."
#define LEGAL_TRADEMARKS	"oriole."
#define ORIGINAL_FILENAME	"Floatscript.oriole"
#define PRODUCT_NAME	"Floatscript.oriole"
#define PRODUCT_VERSION	"1.0.0.0"

#endif /*FLOATSCRIPT_ORIOLE_PRIVATE_H*/
