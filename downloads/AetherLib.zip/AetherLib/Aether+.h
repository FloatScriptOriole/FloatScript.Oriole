#ifndef AETHER_INFERENCE_ENGINE_H
#define AETHER_INFERENCE_ENGINE_H

#include <vector>
#include <functional>
#include <memory>
#include <cmath>
#include <random>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <stdexcept>
#include <limits>
#include <cassert>
#include <map>
#include <string>
#include <fstream>
#include <ctime>
#include <sstream>
#include <queue>
#include <set> // Using std::set for topological sort as requested
#include <iomanip>

namespace aether
{
// ----------------------------
// Utilities
// ----------------------------
inline double now_ms()
{
    // Ensure all operands are double for precise calculation
    return static_cast<double>(std::clock()) / (static_cast<double>(CLOCKS_PER_SEC) / 1000.0);
}

template <typename T>
T clamp(T val, T min_val, T max_val)
{
    return std::max(min_val, std::min(val, max_val));
}

// ----------------------------
// Profiler with hierarchical timing
// ----------------------------
struct Profiler
{
    struct Record
    {
        double total_time;
        size_t call_count;
        std::map<std::string, Record> children;
        
        // Explicit C++11 compatible constructor
        Record() : total_time(0.0), call_count(0) {}
    };

    std::map<std::string, Record> records;
    std::vector<std::string> call_stack;

    void start(const std::string &name)
    {
        call_stack.push_back(name);
    }

    void end(double ms)
    {
        if (call_stack.empty())
            return;
        std::string name = call_stack.back();
        call_stack.pop_back();

        // Navigate to the correct record in the hierarchy
        Record *current = &records[name];
        if (!call_stack.empty()) {
            // Traverse the call stack to find the parent record
            Record *temp = &records[call_stack.front()];
            for (size_t i = 1; i < call_stack.size(); ++i) {
                temp = &temp->children[call_stack[i]];
            }
            // The current record is a child of the last item in the remaining call stack
            current = &temp->children[name];
        }
        
        current->total_time += ms;
        current->call_count++;
    }

    void print(std::ostream &os = std::cout, int indent = 0) const
    {
        for (const auto &pair : records)
        {
            os << std::string(indent * 2, ' ') << pair.first << ": "
               << pair.second.total_time << " ms ("
               << pair.second.call_count << " calls, "
               << (pair.second.call_count > 0 ? pair.second.total_time / pair.second.call_count : 0) << " ms avg)\n";
            if (!pair.second.children.empty())
            {
                os << std::string((indent + 1) * 2, ' ') << "Breakdown:\n";
                print_children(pair.second.children, os, indent + 2);
            }
        }
    }

  private:
    void print_children(const std::map<std::string, Record> &children, std::ostream &os, int indent) const
    {
        for (const auto &pair : children)
        {
            os << std::string(indent * 2, ' ') << pair.first << ": "
               << pair.second.total_time << " ms ("
               << pair.second.call_count << " calls)\n";
            if (!pair.second.children.empty())
            {
                print_children(pair.second.children, os, indent + 1);
            }
        }
    }
};

// ----------------------------
// Device enum
// ----------------------------
enum Device
{
    CPU = 0
};

// ----------------------------
// Forward: OpNode for autograd
// ----------------------------
struct OpNode;

struct Tensor
{
    std::vector<float> data;
    std::vector<size_t> shape;
    std::vector<float> grad;
    bool requires_grad;
    // CRITICAL FIX: Use shared_ptr to manage OpNode lifetime and prevent memory leaks.
    std::shared_ptr<OpNode> creator;
    Device device;
    std::string name; // For debugging

    Tensor() : requires_grad(false), creator(nullptr), device(CPU) {}
    Tensor(const std::vector<float> &d, const std::vector<size_t> &s, bool req = false, const std::string &n = "")
        : data(d), shape(s), grad(), requires_grad(req), creator(nullptr), device(CPU), name(n)
    {
        if (prod(shape) != data.size())
            throw std::invalid_argument("tensor size mismatch");
        if (requires_grad)
            grad.assign(data.size(), 0.0f);
    }
    Tensor(std::vector<float> &&d, std::vector<size_t> &&s, bool req = false, const std::string &n = "")
        : data(std::move(d)), shape(std::move(s)), grad(), requires_grad(req), creator(nullptr), device(CPU), name(n)
    {
        if (prod(shape) != data.size())
            throw std::invalid_argument("tensor size mismatch");
        if (requires_grad)
            grad.assign(data.size(), 0.0f);
    }

    size_t size() const { return data.size(); }
    static size_t prod(const std::vector<size_t> &s)
    {
        size_t r = 1;
        for (size_t v : s)
            r *= v;
        return r;
    }

    void zero_grad()
    {
        if (requires_grad)
            std::fill(grad.begin(), grad.end(), 0.0f);
    }
    
    void set_creator(std::shared_ptr<OpNode> op) { creator = op; }

    void backward()
    {
        if (!requires_grad)
            throw std::runtime_error("backward called but requires_grad=false");
        
        // Initialize grad with 1.0 (for scalar loss)
        if (size() == 1) {
            if (grad.empty()) grad.assign(size(), 1.0f);
            else grad[0] = 1.0f;
        } else if (grad.empty()) {
             grad.assign(size(), 0.0f);
        }

        // Topological sort for correct gradient computation order (DFS-based)
        std::vector<std::shared_ptr<OpNode>> topo_order;
        // Used std::set<OpNode *> instead of unordered_set for maximum compatibility
        std::set<OpNode *> visited; 

        std::function<void(std::shared_ptr<OpNode>)> build_topo =
            [&](std::shared_ptr<OpNode> node) {
            if (!node || visited.count(node.get()))
                return;
            visited.insert(node.get());
            
            // Traverse to the creators of the OpNode's inputs
            for (const auto &parent_creator : node->parents_creators)
            {
                build_topo(parent_creator);
            }
            topo_order.push_back(node);
        };

        build_topo(creator);

        // Execute backward in reverse topological order
        for (auto it = topo_order.rbegin(); it != topo_order.rend(); ++it)
        {
            if (*it)
                (*it)->backward();
        }
    }

    // Utility for debugging
    void print(const std::string &label = "") const
    {
        std::cout << label << (label.empty() ? "" : ": ") << "Tensor(";
        for (size_t i = 0; i < shape.size(); ++i)
        {
            if (i > 0)
                std::cout << ", ";
            std::cout << shape[i];
        }
        std::cout << ") = [";
        size_t print_count = std::min(size_t(10), data.size());
        for (size_t i = 0; i < print_count; ++i)
        {
            if (i > 0)
                std::cout << ", ";
            std::cout << std::fixed << std::setprecision(4) << data[i];
        }
        if (data.size() > print_count)
            std::cout << ", ...";
        std::cout << "]";
        if (requires_grad && !grad.empty()) {
            std::cout << " (grad first 3: " 
                      << grad[0] << ", " 
                      << (grad.size() > 1 ? grad[1] : 0.0f) << ", " 
                      << (grad.size() > 2 ? grad[2] : 0.0f) << ")";
        } else if (requires_grad) {
             std::cout << " (grad N/A)";
        }
        std::cout << "\n";
    }
};

// ----------------------------
// Autograd OpNode with memory management
// ----------------------------
struct OpNode
{
    std::vector<Tensor *> inputs;
    std::vector<Tensor *> outputs;
    // Stores shared_ptr to the OpNode that created the input Tensors (the parents).
    std::vector<std::shared_ptr<OpNode>> parents_creators;
    std::function<void()> backward;
    std::string op_name;

    OpNode(const std::vector<Tensor *> &in, const std::vector<Tensor *> &out, std::function<void()> b, const std::string &name = "")
        : inputs(in), outputs(out), backward(b), op_name(name)
    {
        for (Tensor *t : in)
        {
            // Store the shared_ptr to the OpNode that created this input tensor.
            if (t && t->creator) {
                parents_creators.push_back(t->creator);
            }
        }
    }

    ~OpNode() = default;
};

// ----------------------------
// Backend interface (Abstract Base Class)
// ----------------------------
struct IBackend
{
    virtual ~IBackend() {}
    virtual void matmul(const Tensor &A, const Tensor &B, Tensor &out) = 0;
    virtual void add(const Tensor &A, const Tensor &B, Tensor &out) = 0;
    virtual void mul_scalar(const Tensor &A, float scalar, Tensor &out) = 0;
    virtual void relu(const Tensor &A, Tensor &out) = 0;
    virtual void softmax(const Tensor &A, Tensor &out) = 0;
    virtual void sigmoid(const Tensor &A, Tensor &out) = 0;
    virtual void tanh(const Tensor &A, Tensor &out) = 0;
    virtual void dropout(const Tensor &A, float p, Tensor &out, bool training = true) = 0;
    virtual void conv2d(const Tensor &input, const Tensor &weight, const Tensor &bias,
                        int stride, int padding, Tensor &out) = 0;
    virtual void max_pool2d(const Tensor &input, int kernel_size, int stride, Tensor &out) = 0;
    virtual void batch_norm(const Tensor &input, const Tensor &weight, const Tensor &bias,
                            Tensor &running_mean, Tensor &running_var,
                            float momentum, float eps, bool training, Tensor &out) = 0;
};

// ----------------------------
// Optimized CPU backend (Functional)
// ----------------------------
struct CPUBackend : public IBackend
{
    void matmul(const Tensor &A, const Tensor &B, Tensor &out) override {
        if (A.shape.size() != 2 || B.shape.size() != 2)
            throw std::invalid_argument("matmul expects 2D");
        size_t M = A.shape[0], K = A.shape[1], K2 = B.shape[0], N = B.shape[1];
        if (K != K2)
            throw std::invalid_argument("matmul inner dim mismatch");
        out.shape = {M, N};
        out.data.assign(M * N, 0.0f);
        for (size_t i = 0; i < M; ++i) {
            for (size_t j = 0; j < N; ++j) {
                float sum = 0.0f;
                for (size_t k = 0; k < K; ++k) {
                    sum += A.data[i * K + k] * B.data[k * N + j];
                }
                out.data[i * N + j] = sum;
            }
        }
        // Note: requires_grad/grad size handled by the op_ functions
    }

    void add(const Tensor &A, const Tensor &B, Tensor &out) override {
        if (A.size() != B.size())
            throw std::invalid_argument("add size mismatch");
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t i = 0; i < A.size(); ++i)
            out.data[i] = A.data[i] + B.data[i];
    }

    void mul_scalar(const Tensor &A, float scalar, Tensor &out) override {
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t i = 0; i < A.size(); ++i)
            out.data[i] = A.data[i] * scalar;
    }

    void relu(const Tensor &A, Tensor &out) override {
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t i = 0; i < A.size(); ++i)
            out.data[i] = (A.data[i] > 0.0f ? A.data[i] : 0.0f);
    }

    void softmax(const Tensor &A, Tensor &out) override {
        if (A.shape.size() != 2)
            throw std::invalid_argument("softmax expects 2D");
        size_t batch = A.shape[0], features = A.shape[1];
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t b = 0; b < batch; ++b) {
            float maxv = -std::numeric_limits<float>::infinity();
            for (size_t f = 0; f < features; ++f)
                maxv = std::max(maxv, A.data[b * features + f]);
            float sum = 0.0f;
            for (size_t f = 0; f < features; ++f) {
                float e = std::exp(A.data[b * features + f] - maxv);
                out.data[b * features + f] = e;
                sum += e;
            }
            for (size_t f = 0; f < features; ++f)
                out.data[b * features + f] /= sum;
        }
    }

    void sigmoid(const Tensor &A, Tensor &out) override {
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t i = 0; i < A.size(); ++i) {
            out.data[i] = 1.0f / (1.0f + std::exp(-A.data[i]));
        }
    }

    void tanh(const Tensor &A, Tensor &out) override {
        out.shape = A.shape;
        out.data.resize(A.size());
        for (size_t i = 0; i < A.size(); ++i) {
            out.data[i] = std::tanh(A.data[i]);
        }
    }

    void dropout(const Tensor &A, float p, Tensor &out, bool training = true) override {
        out.shape = A.shape;
        out.data.resize(A.size());
        if (training) {
            static std::mt19937 rng(42);
            static std::uniform_real_distribution<float> dist(0.0f, 1.0f);
            float scale = 1.0f / (1.0f - p);
            for (size_t i = 0; i < A.size(); ++i) {
                out.data[i] = (dist(rng) > p) ? A.data[i] * scale : 0.0f;
            }
        } else {
            for (size_t i = 0; i < A.size(); ++i) {
                out.data[i] = A.data[i];
            }
        }
    }

    void conv2d(const Tensor &input, const Tensor &weight, const Tensor &bias,
                int stride, int padding, Tensor &out) override
    {
        if (input.shape.size() != 4 || weight.shape.size() != 4 || bias.shape.size() != 1) {
            throw std::invalid_argument("conv2d expects 4D input/weight and 1D bias");
        }
        size_t N = input.shape[0]; size_t C_in = input.shape[1]; size_t H_in = input.shape[2]; size_t W_in = input.shape[3];
        size_t C_out = weight.shape[0]; size_t K_h = weight.shape[2]; size_t K_w = weight.shape[3];
        if (C_in != weight.shape[1] || C_out != bias.size()) {
            throw std::invalid_argument("conv2d dimension mismatch");
        }
        size_t H_out = (H_in + 2 * padding - K_h) / stride + 1;
        size_t W_out = (W_in + 2 * padding - K_w) / stride + 1;
        out.shape = {N, C_out, H_out, W_out};
        out.data.assign(N * C_out * H_out * W_out, 0.0f);

        std::vector<float> padded_input;
        const float *input_ptr = input.data.data();
        if (padding > 0) {
            size_t H_pad = H_in + 2 * padding;
            size_t W_pad = W_in + 2 * padding;
            padded_input.assign(N * C_in * H_pad * W_pad, 0.0f);
            for (size_t n = 0; n < N; ++n) {
                for (size_t c = 0; c < C_in; ++c) {
                    for (size_t h = 0; h < H_in; ++h) {
                        for (size_t w = 0; w < W_in; ++w) {
                            padded_input[((n * C_in + c) * H_pad + h + padding) * W_pad + w + padding] =
                                input.data[((n * C_in + c) * H_in + h) * W_in + w];
                        }
                    }
                }
            }
            input_ptr = padded_input.data();
        }

        size_t H_eff = padding > 0 ? (H_in + 2 * padding) : H_in;
        size_t W_eff = padding > 0 ? (W_in + 2 * padding) : W_in;

        for (size_t n = 0; n < N; ++n) {
            for (size_t c_out = 0; c_out < C_out; ++c_out) {
                for (size_t h_out = 0; h_out < H_out; ++h_out) {
                    for (size_t w_out = 0; w_out < W_out; ++w_out) {
                        float sum = bias.data[c_out];
                        for (size_t c_in = 0; c_in < C_in; ++c_in) {
                            for (size_t k_h = 0; k_h < K_h; ++k_h) {
                                for (size_t k_w = 0; k_w < K_w; ++k_w) {
                                    size_t h_in = h_out * stride + k_h;
                                    size_t w_in = w_out * stride + k_w;
                                    size_t input_idx;
                                    input_idx = ((n * C_in + c_in) * H_eff + h_in) * W_eff + w_in;
                                    size_t weight_idx = ((c_out * C_in + c_in) * K_h + k_h) * K_w + k_w;
                                    sum += input_ptr[input_idx] * weight.data[weight_idx];
                                }
                            }
                        }
                        out.data[((n * C_out + c_out) * H_out + h_out) * W_out + w_out] = sum;
                    }
                }
            }
        }
    }

    void max_pool2d(const Tensor &input, int kernel_size, int stride, Tensor &out) override {
        if (input.shape.size() != 4) {
            throw std::invalid_argument("max_pool2d expects 4D input");
        }
        size_t N = input.shape[0]; size_t C = input.shape[1];
        size_t H_in = input.shape[2]; size_t W_in = input.shape[3];
        size_t H_out = (H_in - kernel_size) / stride + 1;
        size_t W_out = (W_in - kernel_size) / stride + 1;
        out.shape = {N, C, H_out, W_out};
        out.data.assign(N * C * H_out * W_out, 0.0f);

        for (size_t n = 0; n < N; ++n) {
            for (size_t c = 0; c < C; ++c) {
                for (size_t h_out = 0; h_out < H_out; ++h_out) {
                    for (size_t w_out = 0; w_out < W_out; ++w_out) {
                        float max_val = -std::numeric_limits<float>::infinity();
                        for (int k_h = 0; k_h < kernel_size; ++k_h) {
                            for (int k_w = 0; k_w < kernel_size; ++k_w) {
                                size_t h_in = h_out * stride + k_h;
                                size_t w_in = w_out * stride + k_w;
                                float val = input.data[((n * C + c) * H_in + h_in) * W_in + w_in];
                                max_val = std::max(max_val, val);
                            }
                        }
                        out.data[((n * C + c) * H_out + h_out) * W_out + w_out] = max_val;
                    }
                }
            }
        }
    }

    void batch_norm(const Tensor &input, const Tensor &weight, const Tensor &bias,
                    Tensor &running_mean, Tensor &running_var,
                    float momentum, float eps, bool training, Tensor &out) override
    {
        if (input.shape.size() != 2 || weight.shape.size() != 1 || bias.shape.size() != 1) {
            throw std::invalid_argument("batch_norm expects 2D input and 1D weight/bias");
        }
        size_t batch = input.shape[0];
        size_t features = input.shape[1];
        if (weight.size() != features || bias.size() != features ||
            running_mean.size() != features || running_var.size() != features) {
            throw std::invalid_argument("batch_norm dimension mismatch");
        }
        out.shape = input.shape;
        out.data.resize(input.size());

        if (training) {
            std::vector<float> mean(features, 0.0f);
            std::vector<float> var(features, 0.0f);
            for (size_t f = 0; f < features; ++f) {
                for (size_t b = 0; b < batch; ++b) mean[f] += input.data[b * features + f];
                mean[f] /= batch;
                for (size_t b = 0; b < batch; ++b) {
                    float diff = input.data[b * features + f] - mean[f];
                    var[f] += diff * diff;
                }
                var[f] /= batch;
                running_mean.data[f] = momentum * running_mean.data[f] + (1.0f - momentum) * mean[f];
                running_var.data[f] = momentum * running_var.data[f] + (1.0f - momentum) * var[f];
            }
            for (size_t b = 0; b < batch; ++b) {
                for (size_t f = 0; f < features; ++f) {
                    float normalized = (input.data[b * features + f] - mean[f]) / std::sqrt(var[f] + eps);
                    out.data[b * features + f] = weight.data[f] * normalized + bias.data[f];
                }
            }
        } else {
            for (size_t b = 0; b < batch; ++b) {
                for (size_t f = 0; f < features; ++f) {
                    float normalized = (input.data[b * features + f] - running_mean.data[f]) /
                                       std::sqrt(running_var.data[f] + eps);
                    out.data[b * features + f] = weight.data[f] * normalized + bias.data[f];
                }
            }
        }
    }
};

// ----------------------------
// Advanced autograd ops (with shared_ptr for memory safety)
// ----------------------------
// Utility function to set output properties and autograd structure
void prepare_output_tensor(Tensor &out, const Tensor &A, const Tensor &B, const std::string &op_name, const std::function<void()> &backward_fn)
{
    out.requires_grad = A.requires_grad || (B.size() > 0 && B.requires_grad);
    if (out.requires_grad) {
        if (out.grad.size() != out.size())
            out.grad.assign(out.size(), 0.0f);
        
        std::vector<Tensor *> inputs;
        inputs.push_back(const_cast<Tensor *>(&A));
        if (B.size() > 0) inputs.push_back(const_cast<Tensor *>(&B));

        auto node = std::make_shared<OpNode>(
            inputs, std::vector<Tensor *>{&out}, backward_fn, op_name);
        out.set_creator(node);
    }
}

inline Tensor op_add(const Tensor &A, const Tensor &B, IBackend &backend)
{
    Tensor out;
    backend.add(A, B, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *b = const_cast<Tensor *>(&B);
    Tensor *o = &out;
    prepare_output_tensor(out, A, B, "add", [a, b, o]() {
        if (a->requires_grad)
            for (size_t i = 0; i < a->size(); ++i)
                a->grad[i] += o->grad[i];
        if (b->requires_grad)
            for (size_t i = 0; i < b->size(); ++i)
                b->grad[i] += o->grad[i];
    });
    return out;
}

inline Tensor op_mul_scalar(const Tensor &A, float scalar, IBackend &backend)
{
    Tensor out;
    backend.mul_scalar(A, scalar, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    // Empty Tensor for B since it's a scalar op.
    prepare_output_tensor(out, A, Tensor(), "mul_scalar", [a, o, scalar]() { 
        for(size_t i=0;i<a->size();++i) a->grad[i]+=o->grad[i]*scalar; 
    });
    return out;
}

inline Tensor op_matmul(const Tensor &A, const Tensor &B, IBackend &backend)
{
    Tensor out;
    backend.matmul(A, B, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *b = const_cast<Tensor *>(&B);
    Tensor *o = &out;
    size_t M = a->shape[0], K = a->shape[1], N = b->shape[1];

    prepare_output_tensor(out, A, B, "matmul", [a, b, o, M, K, N]() {
        if (a->requires_grad)
        {
            // dL/dA = dL/dOut * B^T
            for (size_t i = 0; i < M; ++i)
            {
                for (size_t k = 0; k < K; ++k)
                {
                    float s = 0.0f;
                    for (size_t j = 0; j < N; ++j)
                    {
                        s += o->grad[i * N + j] * b->data[k * N + j]; 
                    }
                    a->grad[i * K + k] += s;
                }
            }
        }
        if (b->requires_grad)
        {
            // dL/dB = A^T * dL/dOut
            for (size_t k = 0; k < K; ++k)
            {
                for (size_t j = 0; j < N; ++j)
                {
                    float s = 0.0f;
                    for (size_t i = 0; i < M; ++i)
                    {
                        s += a->data[i * K + k] * o->grad[i * N + j];
                    }
                    b->grad[k * N + j] += s;
                }
            }
        }
    });
    return out;
}

inline Tensor op_relu(const Tensor &A, IBackend &backend)
{
    Tensor out;
    backend.relu(A, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    prepare_output_tensor(out, A, Tensor(), "relu", [a, o]() {
        for (size_t i = 0; i < a->size(); ++i)
        {
            a->grad[i] += (a->data[i] > 0.0f ? o->grad[i] : 0.0f);
        }
    });
    return out;
}

inline Tensor op_softmax(const Tensor &A, IBackend &backend)
{
    Tensor out;
    backend.softmax(A, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    size_t batch = a->shape[0], features = a->shape[1];
    prepare_output_tensor(out, A, Tensor(), "softmax", [a, o, batch, features]() {
        for (size_t b = 0; b < batch; ++b)
        {
            for (size_t i = 0; i < features; ++i)
            {
                float sum = 0.0f;
                for (size_t j = 0; j < features; ++j)
                {
                    // Jacobian of softmax
                    float pij = o->data[b * features + i];
                    float pjk = o->data[b * features + j];
                    float gij = (i == j) ? pij * (1.0f - pij) : -pij * pjk;
                    sum += gij * o->grad[b * features + j];
                }
                a->grad[b * features + i] += sum;
            }
        }
    });
    return out;
}

inline Tensor op_sigmoid(const Tensor &A, IBackend &backend)
{
    Tensor out;
    backend.sigmoid(A, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    prepare_output_tensor(out, A, Tensor(), "sigmoid", [a, o]() {
        for (size_t i = 0; i < a->size(); ++i)
        {
            a->grad[i] += o->grad[i] * o->data[i] * (1.0f - o->data[i]);
        }
    });
    return out;
}

inline Tensor op_tanh(const Tensor &A, IBackend &backend)
{
    Tensor out;
    backend.tanh(A, out);
    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    prepare_output_tensor(out, A, Tensor(), "tanh", [a, o]() {
        for (size_t i = 0; i < a->size(); ++i)
        {
            a->grad[i] += o->grad[i] * (1.0f - o->data[i] * o->data[i]);
        }
    });
    return out;
}

inline Tensor op_dropout(const Tensor &A, float p, IBackend &backend, bool training = true)
{
    Tensor out;
    backend.dropout(A, p, out, training);
    if (!training) return out; // No autograd if not training

    Tensor *a = const_cast<Tensor *>(&A);
    Tensor *o = &out;
    float scale = 1.0f / (1.0f - p);
    prepare_output_tensor(out, A, Tensor(), "dropout", [a, o, scale]() {
        for (size_t i = 0; i < a->size(); ++i)
        {
            // Gradient is only passed through elements that were not masked out.
            a->grad[i] += (o->data[i] != 0.0f) ? o->grad[i] * scale : 0.0f;
        }
    });
    return out;
}

// ----------------------------
// Parameters wrapper with serialization
// ----------------------------
struct Param
{
    Tensor t;
    std::string name;

    Param() {}
    Param(const Tensor &tensor, const std::string &n) : t(tensor), name(n) {}

    void save(std::ostream &os) const
    {
        size_t name_len = name.length();
        os.write(reinterpret_cast<const char *>(&name_len), sizeof(name_len));
        os.write(name.c_str(), name_len);

        size_t data_size = t.data.size();
        os.write(reinterpret_cast<const char *>(&data_size), sizeof(data_size));
        os.write(reinterpret_cast<const char *>(t.data.data()), data_size * sizeof(float));

        size_t shape_size = t.shape.size();
        os.write(reinterpret_cast<const char *>(&shape_size), sizeof(shape_size));
        os.write(reinterpret_cast<const char *>(t.shape.data()), shape_size * sizeof(size_t));

        os.write(reinterpret_cast<const char *>(&t.requires_grad), sizeof(t.requires_grad));
    }

    void load(std::istream &is)
    {
        size_t name_len;
        is.read(reinterpret_cast<char *>(&name_len), sizeof(name_len));
        name.resize(name_len);
        is.read(&name[0], name_len);

        size_t data_size;
        is.read(reinterpret_cast<char *>(&data_size), sizeof(data_size));
        t.data.resize(data_size);
        is.read(reinterpret_cast<char *>(t.data.data()), data_size * sizeof(float));

        size_t shape_size;
        is.read(reinterpret_cast<char *>(&shape_size), sizeof(shape_size));
        t.shape.resize(shape_size);
        is.read(reinterpret_cast<char *>(t.shape.data()), shape_size * sizeof(size_t));

        is.read(reinterpret_cast<char *>(&t.requires_grad), sizeof(t.requires_grad));
        if (t.requires_grad)
        {
            t.grad.assign(t.data.size(), 0.0f);
        }
    }
};

// ----------------------------
// Module base with serialization and device management
// ----------------------------
class Module
{
  public:
    std::vector<Param> params;
    std::string name;

    Module(const std::string &n = "") : name(n) {}
    virtual ~Module() {}
    virtual Tensor forward(const Tensor &input, IBackend &backend) = 0;
    virtual void zero_grad()
    {
        for (auto &p : params)
            p.t.zero_grad();
    }
    void add_param(Tensor &t, const std::string &name) { 
        // Note: The caller must ensure that the Tensor passed here is the actual parameter.
        params.push_back(Param(t, name)); 
    }

    void save(const std::string &filename)
    {
        std::ofstream file(filename, std::ios::binary);
        if (!file)
            throw std::runtime_error("Cannot open file for saving");
        size_t param_count = params.size();
        file.write(reinterpret_cast<const char *>(&param_count), sizeof(param_count));
        for (const auto &param : params)
        {
            param.save(file);
        }
        file.close();
    }

    void load(const std::string &filename)
    {
        std::ifstream file(filename, std::ios::binary);
        if (!file)
            throw std::runtime_error("Cannot open file for loading");
        size_t param_count;
        file.read(reinterpret_cast<char *>(&param_count), sizeof(param_count));
        params.resize(param_count);
        for (auto &param : params)
        {
            param.load(file);
        }
        file.close();
    }

    void to(Device device)
    {
        for (auto &param : params)
        {
            param.t.device = device;
        }
    }

    // --- New virtual method for Code Generation ---
    virtual std::string get_code_declaration() const = 0;
};

// ----------------------------
// Layers
// ----------------------------
class Linear : public Module
{
  public:
    Tensor W, b;
    size_t in, out;

    Linear(size_t in_, size_t out_, float init_scale = 0.08f, const std::string &name = "Linear")
        : Module(name), in(in_), out(out_)
    {
        std::vector<float> wdata(in_ * out_);
        std::mt19937 rng(std::time(nullptr));
        std::normal_distribution<float> d(0.0f, init_scale);
        for (auto &v : wdata)
            v = d(rng);
        W = Tensor(std::move(wdata), {out, in}, true, name + ".W");
        b = Tensor(std::vector<float>(out, 0.0f), {out}, true, name + ".b");
        // CRITICAL: Must use the mutable Tensor objects in the module for parameters
        add_param(W, name + ".W");
        add_param(b, name + ".b");
    }

    // FIX: Using a single, robust OpNode to handle Matmul and Broadcast Add gradients.
    Tensor forward(const Tensor &input, IBackend &backend)
    {
        // 1. Handle 1D input [N] -> [1, N]
        bool was_1d = (input.shape.size() == 1);
        Tensor input_2d = input;
        if (was_1d) {
            input_2d.shape = {1, input.shape[0]};
        }
        
        // Check input shape match (batch, in)
        if (input_2d.shape.size() != 2 || input_2d.shape[1] != in)
            throw std::invalid_argument("Linear: input size mismatch");

        size_t batch = input_2d.shape[0];

        // 2. Transpose W (shape [out, in]) to Wt (shape [in, out]) for matmul
        std::vector<float> Wt_data(in * out);
        for (size_t r = 0; r < out; ++r) {
            for (size_t c = 0; c < in; ++c) {
                Wt_data[c * out + r] = W.data[r * in + c];
            }
        }
        // Wt is disposable and does not require gradient
        Tensor Wt(std::move(Wt_data), {in, out}, false, "W_transposed");

        // 3. Matmul: input[batch, in] * Wt[in, out] -> output[batch, out]
        Tensor output;
        backend.matmul(input_2d, Wt, output);

        // 4. Manual Bias Add (mutating output data directly)
        for (size_t i = 0; i < batch; ++i)
        {
            for (size_t j = 0; j < out; ++j)
            {
                output.data[i * out + j] += b.data[j];
            }
        }
        
        // 5. Set Autograd with a single, comprehensive OpNode
        output.requires_grad = input.requires_grad || W.requires_grad || b.requires_grad;
        if (output.requires_grad)
        {
            if (output.grad.size() != output.size())
                output.grad.assign(output.size(), 0.0f);

            Tensor *a = const_cast<Tensor *>(&input_2d);
            Tensor *w = &W; // Actual parameter W [out, in]
            Tensor *bias = &b; // Actual parameter b [out]
            Tensor *o = &output; // The output of the layer
            
            auto node = std::make_shared<OpNode>(
                std::vector<Tensor *>{a, w, bias}, std::vector<Tensor *>{o}, [a, w, bias, o, in, out, batch]() {
                    // dL/dOut is o->grad
                    
                    // 1. dL/dW = a^T * dL/dOut (Accumulate to W)
                    if (w->requires_grad) {
                        for (size_t r = 0; r < out; ++r) { // row of W
                            for (size_t c = 0; c < in; ++c) { // column of W
                                float s = 0.0f;
                                for (size_t i = 0; i < batch; ++i) {
                                    // a[i*in + c] * dL/dOut[i*out + r]
                                    s += a->data[i * in + c] * o->grad[i * out + r];
                                }
                                w->grad[r * in + c] += s;
                            }
                        }
                    }
                    
                    // 2. dL/dA = dL/dOut * W^T (Accumulate to A)
                    if (a->requires_grad) {
                        for (size_t i = 0; i < batch; ++i) { // batch
                            for (size_t k = 0; k < in; ++k) { // in dim
                                float s = 0.0f;
                                for (size_t j = 0; j < out; ++j) { // out dim
                                    // dL/dOut[i*out + j] * W.data[j*in + k] (W is [out, in])
                                    s += o->grad[i * out + j] * w->data[j * in + k];
                                }
                                a->grad[i * in + k] += s;
                            }
                        }
                    }
                    
                    // 3. dL/db = sum_i(dL/dOut[i, j]) (Accumulate to b)
                    if (bias->requires_grad) {
                        for (size_t j = 0; j < out; ++j) { // out dim
                            for (size_t i = 0; i < batch; ++i) { // batch
                                bias->grad[j] += o->grad[i * out + j];
                            }
                        }
                    }

                },
                name + ".Linear_Op");
            o->set_creator(node);
        }

        // 6. Restore shape if needed [1, out] -> [out]
        if (was_1d)
        {
            output.shape = {out};
        }

        return output;
    }

    std::string get_code_declaration() const override
    {
        std::stringstream ss;
        ss << "std::make_shared<Linear>(" << in << ", " << out << ", 0.08f, \"" << name << "\")";
        return ss.str();
    }
};

class Conv2D : public Module
{
  public:
    Tensor weight, bias;
    size_t in_channels, out_channels, kernel_size;
    int stride, padding;

    Conv2D(size_t in_ch, size_t out_ch, size_t kernel, int stride_ = 1, int padding_ = 0,
           float init_scale = 0.1f, const std::string &name = "Conv2D")
        : Module(name), in_channels(in_ch), out_channels(out_ch), kernel_size(kernel),
          stride(stride_), padding(padding_)
    {
        std::vector<float> wdata(out_ch * in_ch * kernel * kernel);
        std::mt19937 rng(std::time(nullptr));
        std::normal_distribution<float> d(0.0f, init_scale);
        for (auto &v : wdata)
            v = d(rng);
        weight = Tensor(std::move(wdata), {out_ch, in_ch, kernel, kernel}, true, name + ".weight");

        bias = Tensor(std::vector<float>(out_ch, 0.0f), {out_ch}, true, name + ".bias");
        add_param(weight, name + ".weight");
        add_param(bias, name + ".bias");
    }

    Tensor forward(const Tensor &input, IBackend &backend)
    {
        Tensor out;
        backend.conv2d(input, weight, bias, stride, padding, out);
        // NOTE: Autograd wrapper (op_conv2d) is omitted for brevity and complexity, 
        // rely on the user to implement the corresponding op for full autograd.
        return out;
    }

    std::string get_code_declaration() const override
    {
        std::stringstream ss;
        ss << "std::make_shared<Conv2D>(" << in_channels << ", " << out_channels << ", "
           << kernel_size << ", " << stride << ", " << padding << ", 0.1f, \"" << name << "\")";
        return ss.str();
    }
};

class BatchNorm1D : public Module
{
  public:
    Tensor weight, bias, running_mean, running_var;
    size_t num_features;
    float momentum, eps;
    bool training;

    BatchNorm1D(size_t features, float momentum_ = 0.1f, float eps_ = 1e-5f, const std::string &name = "BatchNorm1D")
        : Module(name), num_features(features), momentum(momentum_), eps(eps_), training(true)
    {
        weight = Tensor(std::vector<float>(features, 1.0f), {features}, true, name + ".weight");
        bias = Tensor(std::vector<float>(features, 0.0f), {features}, true, name + ".bias");
        running_mean = Tensor(std::vector<float>(features, 0.0f), {features}, false, name + ".running_mean");
        running_var = Tensor(std::vector<float>(features, 1.0f), {features}, false, name + ".running_var");

        add_param(weight, name + ".weight");
        add_param(bias, name + ".bias");
        // Running mean/var are NOT parameters, they are persistent state (not added to params)
    }

    Tensor forward(const Tensor &input, IBackend &backend)
    {
        Tensor out;
        backend.batch_norm(input, weight, bias, running_mean, running_var, momentum, eps, training, out);
        // NOTE: Autograd wrapper for BatchNorm is omitted for complexity, 
        // rely on the user to implement the corresponding op for full autograd.
        return out;
    }

    void train() { training = true; }
    void eval() { training = false; }

    std::string get_code_declaration() const override
    {
        std::stringstream ss;
        ss << "std::make_shared<BatchNorm1D>(" << num_features << ", " << momentum << "f, "
           << eps << "f, \"" << name << "\")";
        return ss.str();
    }
};

// ----------------------------
// Sequential container
// ----------------------------
class Sequential : public Module
{
  public:
    std::vector<std::shared_ptr<Module>> layers;
    std::vector<std::string> layer_names;

    Sequential(const std::string &n = "Sequential") : Module(n) {}

    void add(const std::string &name, std::shared_ptr<Module> m)
    {
        layers.push_back(m);
        layer_names.push_back(name);
        m->name = name;
        for (auto &p : m->params)
        {
            params.push_back(p);
        }
    }

    void add(std::shared_ptr<Module> m)
    {
        add("layer_" + std::to_string(layers.size()), m);
    }

    Tensor forward(const Tensor &input, IBackend &backend)
    {
        Tensor x = input;
        for (auto &l : layers)
        {
            x = l->forward(x, backend);
        }
        return x;
    }

    void train()
    {
        for (auto &l : layers)
        {
            if (auto bn = dynamic_cast<BatchNorm1D *>(l.get()))
            {
                bn->train();
            }
        }
    }

    void eval()
    {
        for (auto &l : layers)
        {
            if (auto bn = dynamic_cast<BatchNorm1D *>(l.get()))
            {
                bn->eval();
            }
        }
    }

    std::string get_code_declaration() const override
    {
        std::stringstream ss;
        ss << "auto " << name << "_model = std::make_shared<aether::Sequential>(\"" << name << "\");\n";
        for (size_t i = 0; i < layers.size(); ++i)
        {
            ss << name << "_model->add(\"" << layer_names[i] << "\", " << layers[i]->get_code_declaration() << ");\n";
        }
        ss << "return " << name << "_model;";
        return ss.str();
    }
};

// ----------------------------
// Optimizers (omitted for brevity, they remain unchanged)
// ----------------------------
class Optimizer { /* ... */ };
class SGD : public Optimizer { /* ... */ };
class Adam : public Optimizer
{
  public:
    float lr, beta1, beta2, eps;
    size_t step_count;
    std::vector<std::vector<float>> m, v;

    Adam(float lr_ = 1e-3f, float beta1_ = 0.9f, float beta2_ = 0.999f, float eps_ = 1e-8f)
        : lr(lr_), beta1(beta1_), beta2(beta2_), eps(eps_), step_count(0) {}

    void step(std::vector<Param> &params)
    {
        if (m.empty())
        {
            m.resize(params.size());
            v.resize(params.size());
            for (size_t i = 0; i < params.size(); ++i)
            {
                m[i].assign(params[i].t.size(), 0.0f);
                v[i].assign(params[i].t.size(), 0.0f);
            }
        }

        step_count++;
        
        // FIX for C++11 std::pow ambiguity: use double for math functions
        double b1 = static_cast<double>(beta1);
        double b2 = static_cast<double>(beta2);
        double sc = static_cast<double>(step_count);

        float bias_correction1 = 1.0f / (1.0f - static_cast<float>(std::pow(b1, sc)));
        float bias_correction2 = 1.0f / (1.0f - static_cast<float>(std::pow(b2, sc)));

        for (size_t i = 0; i < params.size(); ++i)
        {
            if (!params[i].t.requires_grad)
                continue;

            for (size_t j = 0; j < params[i].t.size(); ++j)
            {
                m[i][j] = beta1 * m[i][j] + (1.0f - beta1) * params[i].t.grad[j];
                v[i][j] = beta2 * v[i][j] + (1.0f - beta2) * params[i].t.grad[j] * params[i].t.grad[j];
                float m_hat = m[i][j] * bias_correction1;
                float v_hat = v[i][j] * bias_correction2;
                params[i].t.data[j] -= lr * m_hat / (std::sqrt(v_hat) + eps);
            }
        }
    }
};


// ----------------------------
// Reasoner (omitted for brevity, they remain unchanged)
// ----------------------------
struct Reasoner { /* ... */ };
struct SimpleScoreReasoner : public Reasoner { /* ... */ };
struct ThompsonSamplingReasoner : public Reasoner { /* ... */ };
// ----------------------------
// AutoTuner (omitted for brevity, they remain unchanged)
// ----------------------------
struct AutoTuner { /* ... */ };
// ----------------------------
// Loss functions (omitted for brevity, they remain unchanged)
// ----------------------------
inline Tensor mse_loss(const Tensor &pred, const Tensor &target, IBackend &backend) { /* ... */ }
inline Tensor cross_entropy_loss(const Tensor &logits, const Tensor &targets, IBackend &backend) { /* ... */ }


// ----------------------------
// Model Structure Code Generator
// ----------------------------
class CodeGenerator
{
public:
    static std::string generate_model_code(const Sequential &model, const std::string &model_class_name)
    {
        std::stringstream ss;
        ss << "// This file was automatically generated by Aether.h's self-reconfigure feature.\n";
        ss << "// Use this code to replace or define your model structure.\n\n";
        ss << "#include \"Aether.h\"\n";
        ss << "\n";
        ss << "std::shared_ptr<aether::Sequential> " << model_class_name << "()\n";
        ss << "{\n";
        ss << "    using namespace aether;\n";
        ss << "    " << model.get_code_declaration() << "\n";
        ss << "}\n";
        return ss.str();
    }
};


// ----------------------------
// Inference Engine
// ----------------------------
class InferenceEngine
{
  public:
    std::unique_ptr<IBackend> backend;
    Profiler profiler;
    AutoTuner tuner;
    std::unique_ptr<Reasoner> reasoner;

    InferenceEngine(IBackend *b = nullptr, Reasoner *r = nullptr)
        : backend(b ? b : new CPUBackend()),
          tuner(32, 1e-3f),
          reasoner(r ? r : new SimpleScoreReasoner()) {}

    ~InferenceEngine() = default;

    Tensor forward(Module &model, const Tensor &input)
    {
        double t0 = now_ms();
        Tensor out = model.forward(input, *backend);
        double t1 = now_ms();
        profiler.start("forward");
        profiler.end(t1 - t0);
        return out;
    }

    void backward(Tensor &loss)
    {
        double t0 = now_ms();
        loss.backward();
        double t1 = now_ms();
        profiler.start("backward");
        profiler.end(t1 - t0);
    }

    void step(Optimizer &opt, std::vector<Param> &params)
    {
        double t0 = now_ms();
        opt.step(params);
        double t1 = now_ms();
        profiler.start("optimizer_step");
        profiler.end(t1 - t0);
    }

    void zero_grad(std::vector<Param> &params)
    {
        double t0 = now_ms();
        for (auto &p : params)
            p.t.zero_grad();
        double t1 = now_ms();
        profiler.start("zero_grad");
        profiler.end(t1 - t0);
    }

    void info()
    {
        std::cout << "[InferenceEngine] Profiling info:\n";
        profiler.print();
    }

    std::string reason(const std::vector<std::string> &candidates,
                       std::function<float(const std::string &)> score_fn)
    {
        return reasoner->plan(candidates, score_fn);
    }

    struct EvaluationMetrics
    {
        float loss = 0.0f;
        float accuracy = 0.0f;
        float precision = 0.0f;
        float recall = 0.0f;
    };

    EvaluationMetrics evaluate(Module &model, const std::vector<Tensor> &inputs,
                               const std::vector<Tensor> &targets,
                               std::function<Tensor(const Tensor &, const Tensor &, IBackend &)> loss_fn)
    {
        // ... (evaluate logic remains the same)
        model.eval();
        EvaluationMetrics metrics;
        float total_loss = 0.0f;
        size_t correct = 0, total = 0;

        for (size_t i = 0; i < inputs.size(); ++i)
        {
            Tensor output = forward(model, inputs[i]);
            // NOTE: Must pass a copy of the input/target without requires_grad=true to loss for evaluation 
            // to prevent graph creation/memory leak issues if the tensors are large.
            Tensor target_copy = targets[i];
            target_copy.requires_grad = false;
            Tensor loss = loss_fn(output, target_copy, *backend);
            total_loss += loss.data[0];

            if (output.shape.size() == 2 && targets[i].shape.size() == 1)
            {
                size_t batch = output.shape[0];
                size_t classes = output.shape[1];
                for (size_t b = 0; b < batch; ++b)
                {
                    size_t pred_class = 0;
                    float max_val = output.data[b * classes];
                    for (size_t c = 1; c < classes; ++c)
                    {
                        if (output.data[b * classes + c] > max_val)
                        {
                            max_val = output.data[b * classes + c];
                            pred_class = c;
                        }
                    }
                    size_t true_class = static_cast<size_t>(targets[i].data[b]);
                    if (pred_class == true_class)
                        correct++;
                    total++;
                }
            }
        }

        metrics.loss = total_loss / inputs.size();
        metrics.accuracy = total > 0 ? static_cast<float>(correct) / total : 0.0f;
        tuner.record_performance(metrics.loss);

        model.train(); // Set back to training mode
        return metrics;
    }

    void tune(Module &model, const std::vector<Tensor> &train_inputs,
              const std::vector<Tensor> &train_targets,
              std::function<Tensor(const Tensor &, const Tensor &, IBackend &)> loss_fn,
              Optimizer &opt, int epochs = 5)
    {
        // ... (tune logic remains the same)
        std::cout << "[AutoTuner] Starting hyperparameter tuning...\n";

        for (int epoch = 0; epoch < epochs; ++epoch)
        {
            // Train for one epoch with current hyperparameters
            for (size_t i = 0; i < train_inputs.size(); ++i)
            {
                zero_grad(model.params);
                Tensor output = forward(model, train_inputs[i]);
                Tensor loss = loss_fn(output, train_targets[i], *backend);
                backward(loss);
                step(opt, model.params);
            }

            // Evaluate
            auto metrics = evaluate(model, train_inputs, train_targets, loss_fn);
            std::cout << "Epoch " << epoch << ": loss=" << metrics.loss
                      << ", accuracy=" << metrics.accuracy << "\n";

            // Update tuner
            tuner.record_performance(metrics.loss);
        }

        // Optimize hyperparameters
        tuner.meta_optimize();
    }
    
    // --------------------------------------------------------
    // New Self-Modification Capability: Model Reconfiguration
    // --------------------------------------------------------
    /**
     * @brief Analyzes the best performing model structure from a set of candidates 
     * and writes the C++ code for the optimal structure to a file.
     * @param model_candidates A list of sequential models to evaluate/compare.
     * @param input_for_evaluation An input tensor used to run forward pass on candidates.
     * @param output_filename The name of the C++ file to write the new model structure to.
     * @param model_class_name The name of the function/model to generate in the file.
     */
    void self_reconfigure_model(const std::vector<std::shared_ptr<Sequential>> &model_candidates,
                                const Tensor &input_for_evaluation,
                                const std::string &output_filename = "OptimizedModel.cpp",
                                const std::string &model_class_name = "create_optimized_model")
    {
        std::cout << "[Self-Reconfigure] Analyzing " << model_candidates.size() << " model candidates...\n";

        // Step 1: Evaluate candidates using the Reasoner (or a simple latency check)
        float best_score = std::numeric_limits<float>::infinity();
        std::shared_ptr<Sequential> best_model = nullptr;
        
        for (auto &candidate : model_candidates)
        {
            candidate->eval();
            
            // Measure latency as the score (lower is better for self-optimization)
            double t0 = now_ms();
            candidate->forward(input_for_evaluation, *backend);
            double t1 = now_ms();
            
            float latency = static_cast<float>(t1 - t0);

            if (latency < best_score)
            {
                best_score = latency;
                best_model = candidate;
            }
        }
        
        if (!best_model)
        {
            std::cerr << "[Self-Reconfigure] Error: No valid model candidate found.\n";
            return;
        }

        std::cout << "[Self-Reconfigure] Best model structure found with latency: " << best_score << " ms.\n";

        // Step 2: Generate C++ code for the best model structure
        std::string model_code = CodeGenerator::generate_model_code(*best_model, model_class_name);

        // Step 3: Write the generated code to a file
        std::ofstream file(output_filename);
        if (!file)
        {
            std::cerr << "[Self-Reconfigure] Error: Cannot open file " << output_filename << " for writing.\n";
            return;
        }
        file << model_code;
        file.close();

        std::cout << "\n--- **Self-Modification Complete** ---\n";
        std::cout << "The optimal model structure's C++ code has been written to: **" << output_filename << "**\n";
        std::cout << "You must **re-compile** your application with this generated file to apply the structural change.\n";
        std::cout << "--------------------------------------\n\n";
    }
};

} // namespace aether

#endif // AETHER_INFERENCE_ENGINE_H