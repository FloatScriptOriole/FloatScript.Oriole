import os
import sys
import setuptools
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext

# Manual pybind11 inclusion
class get_pybind_include(object):
    def __init__(self, user=False):
        self.user = user

    def __str__(self):
        import pybind11
        return pybind11.get_include()

ext_modules = [
    Extension(
        "aether_py",
        ["bindings/aether_bindings.cpp"],
        include_dirs=[
            "include",
            get_pybind_include(),
            get_pybind_include(user=True)
        ],
        language='c++',
        extra_compile_args=["-O3", "-fPIC", "-std=c++11"],
    ),
]

setup(
    name="aether-engine",
    version="1.0.0",
    author="Lusungu Luhana",
    author_email="floatscript.oriole@gmail.com",
    description="Aether Neural Network Inference Engine",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    ext_modules=ext_modules,
    zip_safe=False,
    python_requires=">=3.6",
    install_requires=["numpy>=1.19.0"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: C++",
    ],
)
