#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include "../include/Aether.h"

namespace py = pybind11;

PYBIND11_MODULE(aether_py, m) {
    m.doc() = "Aether Neural Network Inference Engine - Python Bindings";

    py::class_<aether::Tensor>(m, "Tensor")
        .def(py::init<const std::vector<float>&, const std::vector<size_t>&, bool, const std::string&>(),
             py::arg("data"), py::arg("shape"), py::arg("requires_grad") = false, py::arg("name") = "")
        .def_readwrite("data", &aether::Tensor::data)
        .def_readwrite("shape", &aether::Tensor::shape)
        .def_readwrite("requires_grad", &aether::Tensor::requires_grad)
        .def("size", &aether::Tensor::size)
        .def("zero_grad", &aether::Tensor::zero_grad)
        .def("backward", &aether::Tensor::backward)
        .def("print", &aether::Tensor::print, py::arg("label") = "");

    py::class_<aether::CPUBackend, aether::IBackend>(m, "CPUBackend")
        .def(py::init<>());

    py::class_<aether::Module, std::shared_ptr<aether::Module>>(m, "Module")
        .def("zero_grad", &aether::Module::zero_grad)
        .def("save", &aether::Module::save)
        .def("load", &aether::Module::load);

    py::class_<aether::Linear, aether::Module, std::shared_ptr<aether::Linear>>(m, "Linear")
        .def(py::init<size_t, size_t, float, const std::string&>(),
             py::arg("in_features"), py::arg("out_features"), 
             py::arg("init_scale") = 0.08f, py::arg("name") = "Linear")
        .def("forward", &aether::Linear::forward);

    py::class_<aether::Sequential, aether::Module, std::shared_ptr<aether::Sequential>>(m, "Sequential")
        .def(py::init<const std::string&>(), py::arg("name") = "Sequential")
        .def("add", py::overload_cast<std::shared_ptr<aether::Module>>(&aether::Sequential::add))
        .def("forward", &aether::Sequential::forward)
        .def("train", &aether::Sequential::train)
        .def("eval", &aether::Sequential::eval);

    py::class_<aether::Adam>(m, "Adam")
        .def(py::init<float, float, float, float>(),
             py::arg("lr") = 1e-3f, py::arg("beta1") = 0.9f, 
             py::arg("beta2") = 0.999f, py::arg("eps") = 1e-8f)
        .def("step", &aether::Adam::step);

    py::class_<aether::InferenceEngine>(m, "InferenceEngine")
        .def(py::init<aether::IBackend*, aether::Reasoner*>(),
             py::arg("backend") = nullptr, py::arg("reasoner") = nullptr)
        .def("forward", &aether::InferenceEngine::forward)
        .def("backward", &aether::InferenceEngine::backward)
        .def("info", &aether::InferenceEngine::info);
}
