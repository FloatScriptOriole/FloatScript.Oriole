# Aether Neural Network Engine

**Version:** 1.0.0  
**Author:** Lusungu Luhana  
**Company:** Oriole  
**Contact:** floatscript.oriole@gmail.com  
**License:** Commercial ($1.20 USD for permanent license)

## Overview

Aether is a lightweight, header-only C++ neural network inference engine with Python bindings. It features automatic differentiation, model optimization, and self-reconfiguration capabilities.

## Features

- ✅ Header-only C++11 library
- ✅ Python bindings via pybind11
- ✅ Automatic differentiation (autograd)
- ✅ Multiple optimizers (SGD, Adam)
- ✅ Cross-platform (Linux, Android, Windows, macOS)
- ✅ Self-modifying model architecture
- ✅ CPU backend with optimized operations

## Installation

### C++ (Header-Only)
\`\`\`cpp
#include "Aether.h"
\`\`\`

### Python
\`\`\`bash
pip install aether-engine
\`\`\`

## Quick Start

### C++ Example
\`\`\`cpp
#include "Aether.h"

int main() {
    using namespace aether;
    
    auto model = std::make_shared<Sequential>("MyModel");
    model->add(std::make_shared<Linear>(784, 128));
    model->add(std::make_shared<Linear>(128, 10));
    
    CPUBackend backend;
    Tensor input({/* data */}, {1, 784}, true);
    Tensor output = model->forward(input, backend);
    
    return 0;
}
\`\`\`

### Python Example
\`\`\`python
import aether_py as aether

model = aether.Sequential("MyModel")
model.add(aether.Linear(784, 128))
model.add(aether.Linear(128, 10))

backend = aether.CPUBackend()
# ... use model
\`\`\`

## Commercial License

**Price:** $1.20 USD (One-time payment for permanent license)

**Purchase and activate your license:**
- Email: floatscript.oriole@gmail.com
- Payment: PayPal, Crypto, Bank Transfer

## Support

For technical support, bug reports, or feature requests:
- Email: floatscript.oriole@gmail.com
- Response time: 24-48 hours

## Credits

Developed by Lusungu Luhana for Oriole  
© 2025 All Rights Reserved
